# VfB Ticket-Vorverkauf → automatischer Apple-Kalender

Dieses kleine Projekt liest regelmäßig die offiziellen VfB-Vorverkaufsseiten
(Heim- und Auswärtsspiele) aus und erzeugt daraus eine `.ics`-Kalenderdatei.
Die Datei wird automatisch alle 6 Stunden per GitHub Actions aktualisiert
und über GitHub Pages veröffentlicht. Du abonnierst die URL einmalig in
Apple Kalender – danach läuft alles von selbst, genau wie bei calovo früher.

Kosten: 0 € (alles im kostenlosen GitHub-Kontingent).

## Einmalige Einrichtung (ca. 10 Minuten)

### 1. GitHub-Account anlegen
1. Gehe auf https://github.com/signup
2. E-Mail, Passwort, Benutzername festlegen, Account bestätigen.

### 2. Neues Repository anlegen
1. Oben rechts auf **+** → **New repository**
2. Name z. B. `vfb-ticket-kalender`
3. **Public** auswählen (Pages funktioniert im Free-Plan nur bei öffentlichen Repos)
4. **Create repository** klicken

### 3. Dateien hochladen
1. Im leeren Repo auf **uploading an existing file** klicken
2. Alle Dateien aus diesem Ordner hochladen – dabei die Ordnerstruktur
   beibehalten:
   - `scraper.py`
   - `requirements.txt`
   - `.github/workflows/update.yml`
   - `docs/vfb-vorverkauf.ics`
   
   Tipp: Du kannst den ganzen Ordner als ZIP hochladen; GitHub im Browser
   erlaubt normalerweise nur Dateien einzeln oder per Drag&Drop – ziehe dazu
   den kompletten entpackten Ordnerinhalt (inkl. der unsichtbaren
   `.github`-Struktur) ins Upload-Fenster. Falls dein Browser den
   `.github`-Ordner nicht mitnimmt: leg im Repo über "Add file" → "Create
   new file" den Pfad `.github/workflows/update.yml` manuell an und füge
   den Inhalt ein (GitHub erstellt die Ordner dabei automatisch).
3. Unten **Commit changes** klicken

### 4. GitHub Pages aktivieren
1. Im Repo auf **Settings** → **Pages**
2. Bei **Source**: "Deploy from a branch" wählen
3. Branch: `main`, Ordner: `/docs` → **Save**
4. Nach ein bis zwei Minuten zeigt GitHub dir die URL an, z. B.:
   `https://DEINNAME.github.io/vfb-ticket-kalender/`

### 5. Actions-Berechtigung prüfen
1. **Settings** → **Actions** → **General**
2. Unter "Workflow permissions" **Read and write permissions** auswählen
   und speichern (damit der Bot die aktualisierte Datei committen darf)

### 6. Ersten Lauf manuell anstoßen
1. Reiter **Actions** → Workflow "VfB Vorverkaufs-Kalender aktualisieren"
2. **Run workflow** → **Run workflow** (grüner Button)
3. Nach ca. 30–60 Sekunden ist er fertig; `docs/vfb-vorverkauf.ics` wurde
   aktualisiert

### 7. In Apple Kalender abonnieren
Deine fertige Kalender-URL lautet:

```
https://DEINNAME.github.io/vfb-ticket-kalender/vfb-vorverkauf.ics
```

- **iPhone/iPad:** Einstellungen → Kalender → Accounts → Account
  hinzufügen → Andere → **Kalenderabo hinzufügen** → obige URL einfügen
  (aber mit `webcal://` statt `https://` am Anfang) → Sichern
- **Mac:** Kalender-App → Ablage → **Neues Kalenderabo…** → URL einfügen → Abonnieren

Ab jetzt aktualisiert sich der Kalender von selbst – GitHub Actions
schreibt alle 6 Stunden neue Termine hinein, Apple Kalender holt sie sich
automatisch ab (Apple prüft Kalenderabos typischerweise alle paar Stunden).

## Wichtige Einschränkungen

- **Es ist ein Scraper, kein offizieller Feed.** Wenn der VfB seine
  Ticketseite umgestaltet, kann `scraper.py` leer bleiben oder Fehler
  werfen. In dem Fall in den "Actions"-Reiter schauen, ob der letzte Lauf
  rot ist, und die Parsing-Logik in `scraper.py` anpassen (die Stelle
  `extract_events` in `scraper.py`).
- Aktuell werden Termine aus **Heim- und Auswärtsspielen** (Bundesliga,
  DFB-Pokal, Europapokal – je nachdem was die VfB-Seite gerade listet)
  erfasst. Dauerkarten- oder Frauen/Jugend-Termine sind nicht enthalten,
  können bei Bedarf aber ergänzt werden (weitere URL in `PAGES` in
  `scraper.py` eintragen).
- Das Jahr wird geraten, wenn die VfB-Seite nur Tag+Monat angibt (Saison
  läuft über den Jahreswechsel). Das funktioniert in der Praxis zuverlässig,
  ist aber keine 100%-Garantie.

## Lokal testen (optional)

```bash
pip install -r requirements.txt
python scraper.py
cat docs/vfb-vorverkauf.ics
```
